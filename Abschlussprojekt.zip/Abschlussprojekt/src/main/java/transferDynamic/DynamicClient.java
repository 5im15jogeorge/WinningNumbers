/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package transferDynamic;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.rmi.*;
import java.rmi.server.UnicastRemoteObject;
import java.util.*;

/**
 *
 * @author 5im15jogeorge
 */
public class DynamicClient extends UnicastRemoteObject implements FileClient {

    private static final long serialVersionUID = 1L;
    public String name;

    public DynamicClient(String n) throws RemoteException {
        super();
        name = n;
    }

    public String getName() throws RemoteException {
        return name;
    }

    public boolean sendData(String filename, byte[] data, int len) throws RemoteException {
        try {
            File f = new File(filename);
            f.createNewFile();
            FileOutputStream out = new FileOutputStream(f, false);
            out.write(data, 0, len);
            out.flush();
            out.close();
            System.out.println("Done writing data...");
        } catch (Exception e) {
            e.printStackTrace();
        }
        return true;
    }
}
