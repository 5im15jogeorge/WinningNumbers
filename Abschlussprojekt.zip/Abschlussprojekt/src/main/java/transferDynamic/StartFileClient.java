/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package transferDynamic;

import java.rmi.Naming;
import java.util.Scanner;

/**
 *
 * @author 5im15jogeorge
 */
public class StartFileClient {

    public static void main(String[] args) {
        try {
            DynamicClient c = new DynamicClient("imed");
            FileServer server = (FileServer) Naming.lookup("//172.25.42.30/abc");
            server.login(c);
            System.out.println("Listening.....");
            Scanner s = new Scanner(System.in);
            while (true) {
                String line = s.nextLine();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

}
