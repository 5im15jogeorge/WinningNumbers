/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package transfer;

import java.rmi.RemoteException;
import java.util.ArrayList;

/**
 *
 * @author 5im15tusavrim
 */
public interface Static {
        public ArrayList<String> getStatic() throws RemoteException;
}
