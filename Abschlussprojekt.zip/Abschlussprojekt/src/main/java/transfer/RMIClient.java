/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package transfer;

import java.net.MalformedURLException;
import java.rmi.Naming;
import java.rmi.NotBoundException;
import java.rmi.RemoteException;
import java.util.ArrayList;

/**
 *
 * @author 5im15tusavrim
 */
public class RMIClient {
    private ArrayList <String> winners = new ArrayList<>();
    private ArrayList <String> days = new ArrayList<>(); ;



    public ArrayList<String> getWinners() throws RemoteException, NotBoundException, MalformedURLException {
        Winner pc1 = (Winner) Naming.lookup("//172.25.42.24/TransferWinners");
        winners = pc1.getWinners();
        return winners;
    }

    public ArrayList<String> getStatic() throws NotBoundException, MalformedURLException, RemoteException {
        Static pc2 = (Static) Naming.lookup("//172.25.42.29/LottoDaten");
        days = pc2.getStatic();
        return days;
    }

    
    public static void main(String[] args) throws RemoteException, NotBoundException, MalformedURLException {
        RMIClient rmi = new RMIClient();
        System.out.println("hallo");
        for (String s: rmi.getWinners()) {
            System.out.println(s);
        }
        
    }
    
    
    
    
}
