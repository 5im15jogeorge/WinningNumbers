/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package beans;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.net.MalformedURLException;
import java.rmi.NotBoundException;
import java.rmi.RemoteException;
import java.util.ArrayList;
import javax.enterprise.context.RequestScoped;
import javax.inject.Named;
import org.json.JSONObject;
import transfer.RMIClient;

/**
 *
 * @author 5im15tusavrim
 */

@Named
@RequestScoped
public class Controller {
    
    RMIClient c = new RMIClient();
    private String winners="";
    private ArrayList<String> test;
    private ArrayList<String> test2;
    private Lotterie euroMillions;
    private Lotterie euroJackpot;
    private Lotterie swissLotto;

    
    public Controller() throws RemoteException, NotBoundException, MalformedURLException{
        
        test = new ArrayList();
        test.add("Gewinner: Sarah Baacher Gewinn: 10 Franken Lotto: EuroMillions");
        test.add("Gewinner: Simon Hilfiger Gewinn: 10 Franken Lotto: SwissLotto");
        test.add("Gewinner: Merlina Ferrari Gewinn: 1 Million Franken Lotto: EuroJackpot");
        
        test2 = new ArrayList();
        test2.add("EuroMillions;Dienstag und Freitag;Frankreich;Paris");
        test2.add("EuroJackpot;Freitag;Finnland;Helsinki");
        test2.add("Swisslotto;Mittwoch und Samstag;Schweiz;Basel");
    }
    
    public void prepareWinners() throws RemoteException, NotBoundException, MalformedURLException{
        RMIClient c = new RMIClient();
        for (String s :c.getWinners()){
//            for (String s : test){
            winners = winners+ s;
            winners+= "\n";
                
        }
            System.out.print(winners);
    }
    public void getJson() throws FileNotFoundException, IOException{
        BufferedReader br = new BufferedReader(new FileReader("D:/BBW/3.Jahr/1. Semester/Modul 426/Workspace/Abschlussprojekt/winningNumbers.json"));
        String line;
        StringBuilder sb = new StringBuilder();
        String ls = System.getProperty("line.separator");
        while ((line = br.readLine()) != null) {
            sb.append(line);
            sb.append(ls);
        }
        JSONObject json = new JSONObject(sb.toString());
        
        System.out.print("Winning Numbers Euromillions: " + json.getString("euromillionsWn"));
        System.out.print("Jackpot Euromillions: " + json.getString("euromillionsJp"));
        
        euroMillions.setWinningnumbeR(""+json.getString("euromillionsWn"));
        euroMillions.setJackpot(json.getString("euromillionsJp")+" Franken");
        euroJackpot.setWinningnumbeR(json.getString("eurojackpotWn"));
        euroJackpot.setJackpot(json.getString("eurojackpotJp")+" Euro");
        swissLotto.setWinningnumbeR(json.getString("swisslottoWn"));
        swissLotto.setJackpot(json.getString("swisslottoJp")+" Franken");
        
                
    }
    public void getData() throws NotBoundException, MalformedURLException, RemoteException{

//       for(String s : rmi.getStatic()){
           for(String s : test2){
           String[] parts = s.split(";");
           switch (parts[0].toLowerCase()){
               case "euromillions": euroMillions = new Lotterie();
                                    euroMillions.setLotteriename(parts[0]);
                                    euroMillions.setZiehungstag(parts[1]);
                                    euroMillions.setZiehungsland(parts[2]);
                                    euroMillions.setZiehungsstadt(parts[3]);
                                    break;
                   
               case "eurojackpot":  euroJackpot = new Lotterie();
                                    euroJackpot.setLotteriename(parts[0]);
                                    euroJackpot.setZiehungstag(parts[1]);
                                    euroJackpot.setZiehungsland(parts[2]);
                                    euroJackpot.setZiehungsstadt(parts[3]); 
                                    break;
                   
               case "swisslotto":   swissLotto = new Lotterie();
                                    swissLotto.setLotteriename(parts[0]);
                                    swissLotto.setZiehungstag(parts[1]);
                                    swissLotto.setZiehungsland(parts[2]);
                                    swissLotto.setZiehungsstadt(parts[3]);
                                    break;
               default:     System.out.println("Nicht gefunden");    
           }
              
       }
           
    }

    public String getWinners() throws RemoteException, NotBoundException, MalformedURLException {
        prepareWinners();
        return winners;
    }

    public Lotterie getEuroMillions() throws RemoteException, NotBoundException, MalformedURLException, IOException {
        getData();
        getJson();
        return euroMillions;
    }

    public Lotterie getEuroJackpot() throws RemoteException, NotBoundException, MalformedURLException, IOException{
        getData();
        getJson();
        return euroJackpot;
    }

    public Lotterie getSwissLotto() throws RemoteException, NotBoundException, MalformedURLException, IOException {
        getData();
        getJson();
        return swissLotto;
    }
    
  
            
    
}
