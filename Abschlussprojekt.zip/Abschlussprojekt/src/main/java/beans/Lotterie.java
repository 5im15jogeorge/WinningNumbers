/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package beans;

import transfer.RMIClient;

/**
 *
 * @author 5im15tusavrim
 */
public class Lotterie {
    private String lotteriename;
    private String ziehungstag;
    private String ziehungsland;
    private String ziehungsstadt;
    private String winningnumbeR;
    private String jackpot;

    RMIClient rmi;

    public Lotterie() {

    }

    public String getLotteriename() {
        return lotteriename;
    }

    public void setLotteriename(String lotteriename) {
        this.lotteriename = lotteriename;
    }

    public String getZiehungstag() {
        return ziehungstag;
    }

    public void setZiehungstag(String ziehungstag) {
        this.ziehungstag = ziehungstag;
    }

    public String getZiehungsland() {
        return ziehungsland;
    }

    public void setZiehungsland(String ziehungsland) {
        this.ziehungsland = ziehungsland;
    }

    public String getWinningnumbeR() {
        return winningnumbeR;
    }

    public void setWinningnumbeR(String winningnumbeR) {
        this.winningnumbeR = winningnumbeR;
    }

    public String getJackpot() {
        return jackpot;
    }

    public void setJackpot(String jackpot) {
        this.jackpot = jackpot;
    }

    public RMIClient getRmi() {
        return rmi;
    }

    public void setRmi(RMIClient rmi) {
        this.rmi = rmi;
    }

    public String getZiehungsstadt() {
        return ziehungsstadt;
    }

    public void setZiehungsstadt(String ziehungsstadt) {
        this.ziehungsstadt = ziehungsstadt;
    }
    
    
    
    
    }



    

