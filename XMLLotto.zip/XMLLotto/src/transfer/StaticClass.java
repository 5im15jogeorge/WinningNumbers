/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package transfer;

import java.rmi.Naming;
import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.server.UnicastRemoteObject;
import java.util.ArrayList;

/**
 *
 * @author 5im15juroesch
 */
public class StaticClass extends UnicastRemoteObject implements Static {
    
    private ArrayList<String> list;

    public StaticClass() throws RemoteException {
         list = new ArrayList<>();
    }

    public ArrayList<String> getMOTD(String name, String tag, String land, String stadt) {
        list.add(name);
        list.add(tag);
        list.add(land);
        list.add(stadt);
        return list;
    }

    public static void main(String[] args) {

        try {
            LocateRegistry.createRegistry(1099);  // Use default Port 1099
        } catch (RemoteException e) {
            System.out.println("Could not start Registry");
        }

        try {

            StaticClass impl = new StaticClass();

            String motdService = "LottoDaten";
            Naming.rebind("//localhost/" + motdService, impl);
        } catch (Exception exc) {
            exc.printStackTrace();
        }

    }

    @Override
    public ArrayList<String> getStatic() throws RemoteException {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

}
