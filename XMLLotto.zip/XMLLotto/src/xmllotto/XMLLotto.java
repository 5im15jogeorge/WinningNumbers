/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package xmllotto;

import java.io.File;
import java.rmi.RemoteException;
import java.util.ArrayList;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import transfer.StaticClass;

/**
 *
 * @author Julien Rösch
 */
public class XMLLotto {

    private Document document;
    ArrayList<String> listName = new ArrayList<>();
    ArrayList<String> listLand = new ArrayList<>();
    ArrayList<String> listTag = new ArrayList<>();
    ArrayList<String> listStadt = new ArrayList<>();

    public XMLLotto(String fileName) {
        try {
            DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
            DocumentBuilder builder = factory.newDocumentBuilder();
            document = builder.parse(new File(fileName));
        } catch (Exception e) {
            System.out.println("ERROR:");
            System.out.println(e.getMessage());
        }
    }

    public String getValueOfSingleChild(Element elem, String tagName) {
        NodeList nList = elem.getElementsByTagName(tagName);
        if (nList.getLength() < 1) {
            return "";
        }
        Node textNode = nList.item(0);
        return textNode.getFirstChild().getNodeValue();
    }

    public void list() throws RemoteException {
        NodeList nList = document.getElementsByTagName("lotterie");
        for (int i = 0; i < nList.getLength(); i++) {
            Element elem = (Element) nList.item(i);
            String name = getValueOfSingleChild(elem, "name");
            String ziehungsTag = getValueOfSingleChild(elem, "ziehungstag");
            String ziehungsLand = getValueOfSingleChild(elem, "ziehungsland");
            String ziehungsStadt = getValueOfSingleChild(elem, "ziehungsland");
            listName.add(name);
            listTag.add(ziehungsTag);
            listLand.add(ziehungsLand);
            listStadt.add(ziehungsStadt);
        }
        for (int i = 0; i < listName.size(); i++) {
            System.out.println(listName.get(i) + " wird am " + listTag.get(i) + " in " + listLand.get(i) + " gezogen");
            
            StaticClass c = new StaticClass();
            c.getMOTD(listName.get(i), listTag.get(i), listLand.get(i), listStadt.get(i));
            
        }

    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws RemoteException {
        String filename = "lotto.xml";
        XMLLotto reader = new XMLLotto(filename);

        reader.list();
    }

}
