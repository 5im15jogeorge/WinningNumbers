/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package winningnumbers_json;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import org.json.JSONObject;

/**
 *
 * @author Jophil George
 */
public class JSONCreator {

    public File jsonFile = new File("winningNumbers.json");

    public JSONCreator() throws IOException {
    }

    public void createJson() throws IOException {

        ContentSwissLotto csl = new ContentSwissLotto();
        ContentEuroMillions cem = new ContentEuroMillions();
        ContentEurojackpot cej = new ContentEurojackpot();

        JSONObject lotto = new JSONObject();

        lotto.put("swisslottoWn", csl.winningNumbers);
        lotto.put("swisslottoJp", csl.jackpot);
        lotto.put("euromillionsWn", cem.winningNumbers);
        lotto.put("euromillionsJp", cem.jackpot);
        lotto.put("eurojackpotWn", cej.winningNumbers);
        lotto.put("eurojackpotJp", cej.jackpot);

        try {
            FileWriter file = new FileWriter(jsonFile);
            file.write(lotto.toString());
            file.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

}
