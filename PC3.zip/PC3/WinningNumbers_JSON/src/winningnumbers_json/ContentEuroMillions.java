/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package winningnumbers_json;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Serializable;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 *
 * @author Jophil George
 */
public class ContentEuroMillions implements Serializable {

    public String content;
    public String jackpot;
    public ArrayList<String> numbersEuroMillions;
    public String winningNumbers;

    public ContentEuroMillions() throws IOException {
        numbersEuroMillions = new ArrayList();
        winningNumbers = "";
        jackpot = "";
        storeWinningNumbersEuroMillions();
        storeJackpotEuroMillions();
    }

    public void getContentFromURL() throws MalformedURLException, UnsupportedEncodingException, IOException {
        URL newsURL = new URL("https://www.swisslos.ch/de/euromillions/information/statistiken/gewinnzahlen-quoten.html");
        InputStream rawInStream = null;
        try {
            HttpURLConnection conn = (HttpURLConnection) newsURL.openConnection();
            //conn.addRequestProperty("User-Agent","Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.0)");
            conn.setRequestMethod("GET");
            rawInStream = conn.getInputStream();
        } catch (Exception e) {
            e.printStackTrace();
        }
        BufferedReader rdr = new BufferedReader(new InputStreamReader(rawInStream, "UTF-8"));
        String line = rdr.readLine();
        StringBuilder sb = new StringBuilder();
        while (line != null) {
            //Process this line
            sb.append(line);
            //and read the next line
            line = rdr.readLine();
            content = sb.toString();
        }
    }

    public void storeWinningNumbersEuroMillions() throws IOException {
        getContentFromURL();
        String text = content;
        String pattern = "(<span class=\"transform__center\">)(.*?)(</span>)";
        Pattern p = Pattern.compile(pattern);
        Matcher m = p.matcher(text);
        while (m.find()) {
            numbersEuroMillions.add(m.group(2).trim());
        }
        for (int i = 0; i < 7; i++) {
            winningNumbers += getNumbersEuroMillions().get(i) + " ";
        }
    }

    public void storeJackpotEuroMillions() throws IOException {
        getContentFromURL();
        String text = content;
        String pattern = "(<div class=\"jackpot___value cf\" data-jackpot-game=\"euromillions\" data-jackpot=\")(.*?)(\")";
        Pattern p = Pattern.compile(pattern);
        Matcher m = p.matcher(text);
        while (m.find()) {
            jackpot = m.group(2).trim();
        }
    }

    //START GETTER & SETTER
    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public ArrayList<String> getNumbersEuroMillions() {
        return numbersEuroMillions;
    }

    public void setNumbersEuroMillions(ArrayList<String> numbersEuroMillions) {
        this.numbersEuroMillions = numbersEuroMillions;
    }

    public String getJackpot() {
        return jackpot;
    }

    public void setJackpot(String jackpot) {
        this.jackpot = jackpot;
    }

    public String getWinningNumbers() {
        return winningNumbers;
    }

    public void setWinningNumbers(String winningNumbers) {
        this.winningNumbers = winningNumbers;
    }
    //END GETTER & SETTER
}
