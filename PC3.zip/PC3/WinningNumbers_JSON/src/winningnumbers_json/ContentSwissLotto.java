/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package winningnumbers_json;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Serializable;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 *
 * @author Jophil George
 */
public class ContentSwissLotto implements Serializable {

    public String content;
    public String jackpot;
    public ArrayList<String> numbersSwissLotto;
    public String winningNumbers;

    public ContentSwissLotto() throws IOException {
        numbersSwissLotto = new ArrayList();
        winningNumbers = "";
        jackpot = "";
        storeWinningNumbersSwissLotto();
        storeJackpotSwissLotto();
    }

    public void getContentFromURL() throws MalformedURLException, UnsupportedEncodingException, IOException {
        URL newsURL = new URL("https://www.swisslos.ch/de/swisslotto/information/statistiken/gewinnzahlen-quoten.html");
        InputStream rawInStream = null;
        try {
            HttpURLConnection conn = (HttpURLConnection) newsURL.openConnection();
            //conn.addRequestProperty("User-Agent","Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.0)");
            conn.setRequestMethod("GET");
            rawInStream = conn.getInputStream();
        } catch (Exception e) {
            e.printStackTrace();
        }
        BufferedReader rdr = new BufferedReader(new InputStreamReader(rawInStream, "UTF-8"));
        String line = rdr.readLine();
        StringBuilder sb = new StringBuilder();
        while (line != null) {
            //Process this line
            sb.append(line);
            //and read the next line
            line = rdr.readLine();
            content = sb.toString();
        }
    }

    public void storeWinningNumbersSwissLotto() throws IOException {
        getContentFromURL();
        String text = content;
        String pattern = "(<span class=\"transform__center\">)(.*?)(</span>)";
        Pattern p = Pattern.compile(pattern);
        Matcher m = p.matcher(text);
        while (m.find()) {
            numbersSwissLotto.add(m.group(2).trim());
        }
        for (int i = 0; i < 8; i++) {
            winningNumbers += getNumbersSwissLotto().get(i) + " ";
        }
    }

    public void storeJackpotSwissLotto() throws IOException {
        getContentFromURL();
        String text = content;
        String pattern = "(<div class=\"jackpot___value cf\" data-jackpot-game=\"swiss_lotto\" data-jackpot=\")(.*?)(\")";
        Pattern p = Pattern.compile(pattern);
        Matcher m = p.matcher(text);
        while (m.find()) {
            jackpot = m.group(2).trim();
        }
    }

    //START GETTER & SETTER
    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public ArrayList<String> getNumbersSwissLotto() {
        return numbersSwissLotto;
    }

    public void setNumbersSwissLotto(ArrayList<String> numbersSwissLotto) {
        this.numbersSwissLotto = numbersSwissLotto;
    }

    public String getJackpot() {
        return jackpot;
    }

    public void setJackpot(String jackpot) {
        this.jackpot = jackpot;
    }

    public String getWinningNumbers() {
        return winningNumbers;
    }

    public void setWinningNumbers(String winningNumbers) {
        this.winningNumbers = winningNumbers;
    }
    //END GETTER & SETTER  
}
