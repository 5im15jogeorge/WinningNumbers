/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package winningnumbers_json;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Serializable;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 *
 * @author Jophil George
 */
public class ContentEurojackpot implements Serializable {

    public String content;
    public String jackpot;
    public ArrayList<String> numbersEurojackpot;
    public String winningNumbers;

    public ContentEurojackpot() throws IOException {
        numbersEurojackpot = new ArrayList();
        winningNumbers = "";
        jackpot = "";
        storeWinningNumbersEurojackpot();
        storeExtraNumbers();
        storeJackpotEurojackpot();
    }
    
    public void getContentFromURL() throws MalformedURLException, UnsupportedEncodingException, IOException {
        URL newsURL = new URL("https://www.eurojackpot.org/gewinnzahlen/");
        InputStream rawInStream = null;
        try {
            HttpURLConnection conn = (HttpURLConnection) newsURL.openConnection();
            conn.addRequestProperty("User-Agent", "Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.0)");
            conn.setRequestMethod("GET");
            rawInStream = conn.getInputStream();
        } catch (Exception e) {
            e.printStackTrace();
        }
        BufferedReader rdr = new BufferedReader(new InputStreamReader(rawInStream, "UTF-8"));
        String line = rdr.readLine();
        StringBuilder sb = new StringBuilder();
        while (line != null) {
            //Process this line
            sb.append(line);
            //and read the next line
            line = rdr.readLine();
            content = sb.toString();
        }
    }

    public void storeWinningNumbersEurojackpot() throws IOException {
        getContentFromURL();
        String text = content;
        String pattern = "(<li>)(.*?)(</li>)";
        Pattern p = Pattern.compile(pattern);
        Matcher m = p.matcher(text);
        while (m.find()) {
            numbersEurojackpot.add(m.group(2).trim());
        }       
        for (int i = 0; i < 7; i++) {
            winningNumbers += getNumbersEurojackpot().get(i) + " ";
        }
    }

    public void storeExtraNumbers() throws UnsupportedEncodingException, IOException {
        getContentFromURL();
        String text = content;
        String pattern = "(<li class=\"extra\">)(.*?)(</li>)";
        Pattern p = Pattern.compile(pattern);
        Matcher m = p.matcher(text);
        while (m.find()) {
            for (int i = 5; i < 7; i++) {
                numbersEurojackpot.add(i, m.group(2).trim());
            }
        }
    }

    public void storeJackpotEurojackpot() throws IOException {
        getContentFromURL();
        String text = content;
        String pattern = "(<p>)([0-9]+)(</p>)";
        Pattern p = Pattern.compile(pattern);
        Matcher m = p.matcher(text);
        while (m.find()) {
            jackpot = m.group(2).trim() + " Mio.";
        }
    }

    //START GETTER & SETTER
    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public ArrayList<String> getNumbersEurojackpot() {
        return numbersEurojackpot;
    }

    public void setNumbersEurojackpot(ArrayList<String> numbersEurojackpot) {
        this.numbersEurojackpot = numbersEurojackpot;
    }

    public String getJackpot() {
        return jackpot;
    }

    public void setJackpot(String jackpot) {
        this.jackpot = jackpot;
    }

    public String getWinningNumbers() {
        return winningNumbers;
    }

    public void setWinningNumbers(String winningNumbers) {
        this.winningNumbers = winningNumbers;
    }
    //END GETTER & SETTER  
}
