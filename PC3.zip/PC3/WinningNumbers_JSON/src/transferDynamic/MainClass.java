/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package transferDynamic;

import java.io.IOException;
import java.rmi.Naming;
import winningnumbers_json.JSONCreator;

/**
 *
 * @author Jophil George
 */
public class MainClass {

    public static void main(String[] args) throws IOException {
        JSONCreator winningNumbers = new JSONCreator();
        winningNumbers.createJson();
        try {

            java.rmi.registry.LocateRegistry.createRegistry(1099);

            DynamicServer fs = new DynamicServer();
            fs.setFile("winningNumbers.json");
            Naming.rebind("//172.25.42.30/abc", fs);
            System.out.println("Der Server ist bereit.");

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
