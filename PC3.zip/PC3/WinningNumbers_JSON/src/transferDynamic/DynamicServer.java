/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package transferDynamic;

import java.io.File;
import java.io.FileInputStream;
import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;

/**
 *
 * @author Jophil George
 */
public class DynamicServer extends UnicastRemoteObject implements FileServer {

    private String file = "";

    protected DynamicServer() throws RemoteException {
        super();
    }

    public void setFile(String f) {
        file = f;
    }

    public boolean login(FileClient c) throws RemoteException {
        try {
            File f1 = new File(file);
            FileInputStream in = new FileInputStream(f1);
            byte[] mydata = new byte[1024 * 1024];
            int mylen = in.read(mydata);
            while (mylen > 0) {
                c.sendData(f1.getName(), mydata, mylen);
                mylen = in.read(mydata);
            }
        } catch (Exception e) {
            e.printStackTrace();

        }

        return true;
    }
}
